//
//  HomeTableViewCell.swift
//  PhotoPicApp
//
//  Created by iblesoft on 12/08/22.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var firstBtn: UIButton!
    @IBOutlet weak var secondBtn: UIButton!
    @IBOutlet weak var thirdBtn: UIButton!
    @IBOutlet weak var fourthBtn: UIButton!
    @IBOutlet weak var firstImg: UIImageView!
    @IBOutlet weak var secondImg: UIImageView!
    @IBOutlet weak var thirdImage: UIImageView!
    @IBOutlet weak var fourthimg: UIImageView!
    
    
    @IBOutlet weak var trash1: UIButton!
    @IBOutlet weak var trash2: UIButton!
    @IBOutlet weak var trash3: UIButton!
    @IBOutlet weak var trash4: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

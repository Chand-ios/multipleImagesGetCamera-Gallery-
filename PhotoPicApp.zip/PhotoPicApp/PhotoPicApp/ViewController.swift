//
//  ViewController.swift
//  PhotoPicApp
//
//  Created by iblesoft on 12/08/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
   
    var picker = UIImagePickerController();
    var viewController: UIViewController?
    var IndexIDs:Int = 0

    @IBOutlet weak var tbl: UITableView!
    var navigStr = ""
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        picker.delegate = self
        tbl.delegate = self
        tbl.dataSource = self

    }

  @objc func  camAction1(_ sender: UIButton){
      navigStr = "FIRST"
    //  let indexPath = IndexPath(row: sender.tag, section: 0)
      IndexIDs = sender.tag
      print(IndexIDs)
      let alert:UIAlertController=UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertController.Style.alert)
      let cameraAction = UIAlertAction(title: "Camera", style: UIAlertAction.Style.default)
          {
             UIAlertAction in
             self.openCamera()
          }
      let gallaryAction = UIAlertAction(title: "Gallary", style: UIAlertAction.Style.default)
          {
             UIAlertAction in
             self.openGallary()
          }
      let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
          {
             UIAlertAction in
          }

         // Add the actions
      picker.delegate = self
          alert.addAction(cameraAction)
          alert.addAction(gallaryAction)
          alert.addAction(cancelAction)
      self.present(alert, animated: true, completion: nil)
    }
    
    @objc func  camAction2(_ sender: UIButton){
        navigStr = "TWO"
      //  let indexPath = IndexPath(row: sender.tag, section: 0)
        IndexIDs = sender.tag
        print(IndexIDs)
        let alert:UIAlertController=UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertController.Style.alert)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertAction.Style.default)
            {
               UIAlertAction in
               self.openCamera()
            }
        let gallaryAction = UIAlertAction(title: "Gallary", style: UIAlertAction.Style.default)
            {
               UIAlertAction in
               self.openGallary()
            }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
            {
               UIAlertAction in
            }

           // Add the actions
        picker.delegate = self
            alert.addAction(cameraAction)
            alert.addAction(gallaryAction)
            alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
      }
    
    @objc func  camAction3(_ sender: UIButton){
        navigStr = "THREE"
      //  let indexPath = IndexPath(row: sender.tag, section: 0)
        IndexIDs = sender.tag
        print(IndexIDs)
        let alert:UIAlertController=UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertController.Style.alert)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertAction.Style.default)
            {
               UIAlertAction in
               self.openCamera()
            }
        let gallaryAction = UIAlertAction(title: "Gallary", style: UIAlertAction.Style.default)
            {
               UIAlertAction in
               self.openGallary()
            }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
            {
               UIAlertAction in
            }

           // Add the actions
        picker.delegate = self
            alert.addAction(cameraAction)
            alert.addAction(gallaryAction)
            alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
      }
    
    @objc func  camAction4(_ sender: UIButton){
        navigStr = "FOUR"
      //  let indexPath = IndexPath(row: sender.tag, section: 0)
        IndexIDs = sender.tag
        print(IndexIDs)
        let alert:UIAlertController=UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertController.Style.alert)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertAction.Style.default)
            {
               UIAlertAction in
               self.openCamera()
            }
        let gallaryAction = UIAlertAction(title: "Gallary", style: UIAlertAction.Style.default)
            {
               UIAlertAction in
               self.openGallary()
            }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
            {
               UIAlertAction in
            }

           // Add the actions
        picker.delegate = self
            alert.addAction(cameraAction)
            alert.addAction(gallaryAction)
            alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
      }

    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
        {
            picker.sourceType = UIImagePickerController.SourceType.camera
            self.present(picker, animated: true, completion: nil)
        }
        else
        {
            let alertWarning = UIAlertView(title:"Warning", message: "You don't have camera", delegate:nil, cancelButtonTitle:"OK", otherButtonTitles:"")
            alertWarning.show()
        }
    }
    
    func openGallary()
    {
        picker.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(picker, animated: true, completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: NSDictionary!) {
        let selectedImage : UIImage = image
        print(selectedImage)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    //PickerView Delegate Methods
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
           // imageView.contentMode = .scaleAspectFit
           // imageView.image = pickedImage
            let indexPath = IndexPath(row: IndexIDs, section: 0)
            print(indexPath)
            let cell = self.tbl.cellForRow(at: indexPath) as? HomeTableViewCell
             if navigStr == "FIRST" {
                 cell?.firstImg.image = pickedImage
                 
             }
           else if navigStr == "TWO" {
               cell?.secondImg.image = pickedImage
            }
            else if navigStr == "THREE" {
                cell?.thirdImage.image = pickedImage

             }
            else if navigStr == "FOUR" {
                cell?.fourthimg.image = pickedImage

             }
            else{
                
            }
            
        }
        dismiss(animated: true, completion: nil)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomeTableViewCell", for: indexPath) as! HomeTableViewCell
        

        cell.selectionStyle = .none
        for item in 0...4 {
            let oneimg = cell.firstImg.image
            let secondimg = cell.secondImg.image
            let thirdimg = cell.thirdImage.image
            let fourthimg = cell.fourthimg.image
            
            if oneimg?.description == "image" {
                cell.trash1.isHidden = true
            }
            else{
                cell.trash1.isHidden = false
            }
            
            if oneimg?.description == "image" {
                cell.trash1.isHidden = true
            }
            else{
                cell.trash1.isHidden = false
            }
            
            if oneimg?.description == "image" {
                cell.trash1.isHidden = true
            }
            else{
                cell.trash1.isHidden = false
            }
            
            if oneimg?.description == "image" {
                cell.trash1.isHidden = true
            }
            else{
                cell.trash1.isHidden = false
            }
        }
        
//        if(indexPath.row == arrImages.count) {
//            cell.firstImg.image = UIImage(named: "image")
//            cell.secondImg.image = UIImage(named: "image")
//            cell.thirdImage.image = UIImage(named: "image")
//            cell.fourthimg.image = UIImage(named: "image")
//
//            lblDelete.isHidden=true
//        } else {
//            imgView.image = arrImages.object(at: indexPath.row) as? UIImage
//            lblDelete.layer.masksToBounds=true
//            lblDelete.layer.cornerRadius = lblDelete.frame.size.width / 2
//            lblDelete.isHidden=false
//        }
//        
        
        cell.firstBtn.addTarget(self, action: #selector(camAction1), for: .touchUpInside)
        cell.secondBtn.addTarget(self, action: #selector(camAction2), for: .touchUpInside)
        cell.thirdBtn.addTarget(self, action: #selector(camAction3), for: .touchUpInside)
        cell.fourthBtn.addTarget(self, action: #selector(camAction4), for: .touchUpInside)
        
        cell.firstBtn.tag = indexPath.row
        cell.secondBtn.tag = indexPath.row
        cell.thirdBtn.tag = indexPath.row
        cell.fourthBtn.tag = indexPath.row


        cell.trash1.addTarget(self, action: #selector(trash), for: .touchUpInside)
        cell.trash2.addTarget(self, action: #selector(trash), for: .touchUpInside)
        cell.trash3.addTarget(self, action: #selector(trash), for: .touchUpInside)
        cell.trash4.addTarget(self, action: #selector(trash), for: .touchUpInside)
        
        
        cell.firstImg.tag = indexPath.row
        cell.secondImg.tag = indexPath.row
        cell.thirdImage.tag = indexPath.row
        cell.fourthimg.tag = indexPath.row
        
        cell.trash1.tag = indexPath.row
        cell.trash2.tag = indexPath.row
        cell.trash3.tag = indexPath.row
        cell.trash4.tag = indexPath.row

        return cell
    }

    
    @objc func trash() {
        let alert:UIAlertController=UIAlertController(title: "Do you want remove Image?", message: nil, preferredStyle: UIAlertController.Style.alert)
        let noAction = UIAlertAction(title: "NO", style: UIAlertAction.Style.default)
            {
               UIAlertAction in
            }
        let yesAction = UIAlertAction(title: "YES", style: UIAlertAction.Style.default)
            {
               UIAlertAction in
               self.removeImage()
            }

           // Add the actions
        picker.delegate = self
            alert.addAction(noAction)
            alert.addAction(yesAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func removeImage(){
        
    }
}

